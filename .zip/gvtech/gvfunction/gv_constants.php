<?
	$GV_PageSSDATA = GVstringEncrption("RECORD_SDPAGE");
	$GV_PopupSSDATA = GVstringEncrption("RECORD_SDPOPUP");
	$GV_PopupCloseSS = GVstringEncrption("POPUP_CLOSE");
	$GV_PageLoadCHK = GVstringEncrption("POPUP_CHECK");
	$GV_sortingArr = array('asc','desc');
?>