<?
	$expenseArr = array();
	$expenseArr["Rent"] = "Rent";
	$expenseArr["Transport"] = "Transport";
	$expenseArr["Travel"] = "Travel";
	$expenseArr["Depreciation"] = "Depreciation";
	$expenseArr["Advertising"] = "Advertising";
	$expenseArr["Interest"] = "Interest";
	$expenseArr["Insurance"] = "Insurance";
	$expenseArr["Taxes"] = "Taxes";
	$expenseArr["Business"] = "Business";
	$expenseArr["Utilities"] = "Utilities";
	$expenseArr["Office supplies"] = "Office supplies";
	$expenseArr["Employee benefits"] = "Employee benefits";
	$expenseArr["Marketing"] = "Marketing";
	$expenseArr["Software"] = "Software";
	$expenseArr["Fixed cost"] = "Fixed cost";
	$expenseArr["Variable cost"] = "Variable cost";
	$expenseArr["Property tax"] = "Property tax";
	$expenseArr["Bank charge"] = "Bank charge";
	$expenseArr["Cost of goods sold"] = "Cost of goods sold";
	$expenseArr["Medicine"] = "Medicine";
	$expenseArr["Wage"] = "Wage";
	$expenseArr["Office"] = "Office";
	$expenseArr["Capital expenditure"] = "Capital expenditure";
	$expenseArr["Meal"] = "Meal";
	
	$payTypeArr = array();
	$payTypeArr["CASH"] = "Cash";
	$payTypeArr["UPI"] = "Gpay / Phone Pe / Paytm";
	$payTypeArr["NETBANKING"] = "Net Banking";
?>