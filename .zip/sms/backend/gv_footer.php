<?
	MyDbClose();
?>
