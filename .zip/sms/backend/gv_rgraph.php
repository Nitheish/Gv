<script type="text/javascript" src='<? echo "/gvtech/rgraph/RGraph.common.core.js"; ?>'></script> 
<script type="text/javascript" src='<? echo "/gvtech/rgraph/RGraph.common.key.js"; ?>'></script>
<script type="text/javascript" src='<? echo "/gvtech/rgraph/RGraph.pie.js"; ?>'></script> 	
<script type="text/javascript" src='<? echo "/gvtech/rgraph/RGraph.common.tooltips.js"; ?>'></script> 
<script type="text/javascript" src='<? echo "/gvtech/rgraph/RGraph.bar.js"; ?>'></script> 
<script type="text/javascript" src='<? echo "/gvtech/rgraph/RGraph.common.dynamic.js"; ?>'></script> 
<script type="text/javascript" src='<? echo "/gvtech/js/echarts.min.js"; ?>'></script>	